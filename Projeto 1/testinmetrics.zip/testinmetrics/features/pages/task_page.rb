class Task < SitePrism::Page
    element :addtask, '.waves-effect.waves-light.red.darken-2.btn.modal-trigger'
    element :description, 'input[placeholder="What will are trying to procrastinate?"]'
    element :data, 

    def preencher_task
        addtask.click
        description.set 'teste'

    end

end