class Pagina < SitePrism::Page
    class Sessao < SitePrism::Section
        element :login, 'a[href="http://www.juliodelima.com.br/taskit/me"]'
        element :mytask, 'a[href="http://www.juliodelima.com.br/taskit/task"]'
        element :logout, 'a[href="http://www.juliodelima.com.br/taskit/user/logout"]'
        element :calendario, '.picker__wrap'
    end
    section :navbar, Sessao, '.grey.black'
    
    def clicarMyTask
        navbar.mytask.click
    end

end