class User < SitePrism::Page
    set_url '/taskit/'
    element :botao, '#signup'
    element :nome, 'input[placeholder="Tell us what is your name"]'
    element :login, 'input[name="login"]'
    element :password, 'input[placeholder="Take care, it need to be remembered"]'
    element :save, '.btn-flat'
    
    def clicar
        botao.click
    end

    def preencher_usuario
        nome.set 'Sandoval'
        login.set 'Neto58'
        password.set '1234'
        save.click
    end





end