Quando("eu cadastro o usuario") do
  user.load
  user.clicar
  user.preencher_usuario
end

Entao("eu verifico se o usuario foi cadastrado") do
  #user.preencher_usuario
  have_text('Hi, Sandoval')
end

Quando("estou logado") do
  pagina.clicarMyTask
  task.preencher_task
end

Entao("eu crio uma task") do
  
end