require 'rest-client'
require 'json'

url = 'https://swapi.co/api/films/'
#q = '/api/fimlms'

resp = RestClient.get "#{url}"

@valor = 0
@quantidade = JSON.parse(resp.body)["count"]

while @valor < @quantidade do
    @titulo = JSON.parse(resp.body)["results"][@valor]["title"]
    @diretor = JSON.parse(resp.body)["results"][@valor]["director"]
    @produtor = JSON.parse(resp.body)["results"][@valor]["producer"]
    
   #         if @diretor[]=("George Lucas") & @produtor[]=("Rick McCallum")
                puts @titulo
                puts @diretor
                puts @produtor
                puts --
        #    end

        
    @valor += 1

end
       